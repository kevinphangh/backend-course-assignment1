namespace WebAPI.Models
{
    public class Dish
    {
        public string Name { get; set; }
        public int? Price { get; set; }
    }
}